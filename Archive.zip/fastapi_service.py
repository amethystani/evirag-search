"""
EVIRAG FastAPI Service
Backend API for the frontend and external integrations.
"""

from typing import Optional, List, Dict, Any, Tuple

import uvicorn
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from evirag_system import EVIRAGSystem, EVIRAGConfig
from mode_comparison import compare_modes


class QueryConfig(BaseModel):
    mode: str = "evirag"
    backend: str = "local"
    enabled_agents: Optional[List[str]] = None
    use_visual_grounding: bool = False
    depth_vs_speed: str = "balanced"
    use_epistemic_divergence: bool = True
    use_causal_attribution: bool = False
    use_temporal_tracking: bool = True
    auto_fallback_to_full: bool = True
    rebuild_index: bool = False


class QueryRequest(BaseModel):
    query: str
    config: Optional[QueryConfig] = None


class EvaluationRequest(BaseModel):
    queries: Optional[List[str]] = None
    backend: str = "local"
    enabled_agents: Optional[List[str]] = None


app = FastAPI(
    title="EVIRAG API",
    description="Evidence-Centric, Disagreement-Aware RAG for Scientific Literature",
    version="2.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

system_registry: Dict[Tuple[Any, ...], EVIRAGSystem] = {}


def _config_to_evirag(config: Optional[QueryConfig]) -> EVIRAGConfig:
    if config is None:
        return EVIRAGConfig(
            mode="evirag",
            backend="local",
            use_visual_grounding=False,
            depth_vs_speed="balanced",
            use_causal_attribution=False,
            auto_fallback_to_full=True,
        )
    return EVIRAGConfig(
        mode=config.mode,
        backend=config.backend,
        enabled_agents=config.enabled_agents,
        use_visual_grounding=config.use_visual_grounding,
        depth_vs_speed=config.depth_vs_speed,
        use_epistemic_divergence=config.use_epistemic_divergence,
        use_causal_attribution=config.use_causal_attribution,
        use_temporal_tracking=config.use_temporal_tracking,
        auto_fallback_to_full=config.auto_fallback_to_full,
        rebuild_index=config.rebuild_index,
    )


def _system_key(config: EVIRAGConfig) -> Tuple[Any, ...]:
    return (
        config.backend,
        config.use_visual_grounding,
        config.use_epistemic_divergence,
        config.use_causal_attribution,
        config.use_temporal_tracking,
    )


def get_or_create_system(config: EVIRAGConfig, rebuild: bool = False) -> EVIRAGSystem:
    key = _system_key(config)
    system = system_registry.get(key)
    if system is None:
        system = EVIRAGSystem(config)
        system.initialize_corpus(rebuild=rebuild or config.rebuild_index)
        system_registry[key] = system
    elif rebuild:
        system.initialize_corpus(rebuild=True)
    return system


@app.on_event("startup")
async def startup_event():
    default_config = EVIRAGConfig(
        mode="evirag",
        backend="local",
        use_visual_grounding=False,
        depth_vs_speed="fast",
        use_causal_attribution=False,
        auto_fallback_to_full=True,
    )
    get_or_create_system(default_config, rebuild=False)


@app.get("/")
async def root():
    return {
        "service": "EVIRAG API",
        "version": "2.0.0",
        "systems_loaded": len(system_registry),
    }


@app.get("/health")
async def health_check():
    return {
        "status": "healthy" if system_registry else "initializing",
        "systems_loaded": len(system_registry),
    }


@app.post("/api/initialize")
async def initialize_system(config: Optional[QueryConfig] = None):
    exec_config = _config_to_evirag(config)
    system = get_or_create_system(exec_config, rebuild=exec_config.rebuild_index)
    return {
        "status": "ready",
        "config": exec_config.__dict__,
        "system": system.get_system_status(),
    }


@app.get("/api/system/status")
async def system_status(
    backend: str = "local",
    use_visual_grounding: bool = False,
    use_epistemic_divergence: bool = True,
    use_causal_attribution: bool = False,
    use_temporal_tracking: bool = True,
):
    config = EVIRAGConfig(
        backend=backend,
        use_visual_grounding=use_visual_grounding,
        use_epistemic_divergence=use_epistemic_divergence,
        use_causal_attribution=use_causal_attribution,
        use_temporal_tracking=use_temporal_tracking,
    )
    system = get_or_create_system(config)
    return system.get_system_status()


@app.post("/api/process_query")
async def process_query(request: QueryRequest):
    exec_config = _config_to_evirag(request.config)
    try:
        system = get_or_create_system(exec_config, rebuild=exec_config.rebuild_index)
        return system.query(request.query, exec_config)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@app.post("/api/rebuild_index")
async def rebuild_index(config: Optional[QueryConfig] = None):
    exec_config = _config_to_evirag(config)
    try:
        system = get_or_create_system(exec_config, rebuild=True)
        return {
            "status": "success",
            "message": "Index rebuilt",
            "system": system.get_system_status(),
        }
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@app.get("/api/corpus/stats")
async def corpus_stats(backend: str = "local"):
    config = EVIRAGConfig(backend=backend)
    system = get_or_create_system(config)
    return {
        "total_chunks": len(system.data_manager.vector_store.chunks),
        "total_documents": len(set(chunk.doc_id for chunk in system.data_manager.vector_store.chunks)),
        "total_claims": len(system.data_manager.claim_graph.claims),
        "total_claim_edges": len(system.data_manager.claim_graph.relationships),
        "total_figures": len(system.visual_processor.visual_evidence_db) if system.visual_processor else 0,
    }


@app.post("/api/batch_process")
async def batch_process(queries: List[str], config: Optional[QueryConfig] = None):
    exec_config = _config_to_evirag(config)
    system = get_or_create_system(exec_config, rebuild=exec_config.rebuild_index)
    results = []
    for query in queries:
        try:
            results.append({
                "query": query,
                "status": "success",
                "result": system.query(query, exec_config),
            })
        except Exception as exc:
            results.append({
                "query": query,
                "status": "error",
                "error": str(exc),
            })
    return {
        "total": len(queries),
        "successful": len([r for r in results if r["status"] == "success"]),
        "failed": len([r for r in results if r["status"] == "error"]),
        "results": results,
    }


@app.post("/api/evaluate_modes")
async def evaluate_modes(request: EvaluationRequest):
    try:
        return compare_modes(
            queries=request.queries,
            backend=request.backend,
            enabled_agents=request.enabled_agents,
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


def run_server(host: str = "0.0.0.0", port: int = 8000):
    uvicorn.run(app, host=host, port=port)


if __name__ == "__main__":
    run_server()

"""
EVIRAG Streamlit Interface
Local-only corpus chat UI with selectable reasoning modes.
"""

from pathlib import Path
import sys
from typing import Any, Dict, List, Tuple

import pandas as pd
import streamlit as st

sys.path.insert(0, str(Path(__file__).parent))

from evirag_system import EVIRAGConfig, EVIRAGSystem
from mode_comparison import compare_modes


st.set_page_config(
    page_title="EVIRAG",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
    .block-container {max-width: 1100px; padding-top: 1.8rem; padding-bottom: 3rem;}
    .mode-chip {
        display: inline-block;
        padding: 0.2rem 0.55rem;
        border-radius: 999px;
        background: rgba(100, 149, 237, 0.12);
        border: 1px solid rgba(100, 149, 237, 0.35);
        font-size: 0.8rem;
        margin-right: 0.4rem;
    }
    .source-card {
        padding: 0.8rem 0.9rem;
        border-radius: 0.8rem;
        border: 1px solid rgba(120, 120, 120, 0.2);
        margin-bottom: 0.75rem;
        background: rgba(255,255,255,0.02);
    }
    </style>
    """,
    unsafe_allow_html=True,
)


MODE_PRESETS = {
    "Fast": {
        "mode": "evirag",
        "depth_vs_speed": "fast",
        "auto_fallback_to_full": True,
        "show_reasoning": False,
    },
    "Balanced": {
        "mode": "evirag",
        "depth_vs_speed": "balanced",
        "auto_fallback_to_full": False,
        "show_reasoning": True,
    },
    "Deep Reasoning": {
        "mode": "evirag",
        "depth_vs_speed": "deep",
        "auto_fallback_to_full": False,
        "show_reasoning": True,
    },
    "Vanilla RAG": {
        "mode": "vanilla_rag",
        "depth_vs_speed": "balanced",
        "auto_fallback_to_full": False,
        "show_reasoning": False,
    },
}


def initialize_session_state():
    if "systems" not in st.session_state:
        st.session_state.systems = {}
    if "messages" not in st.session_state:
        st.session_state.messages = []
    if "latest_result" not in st.session_state:
        st.session_state.latest_result = None
    if "evaluation_result" not in st.session_state:
        st.session_state.evaluation_result = None
    if "active_mode" not in st.session_state:
        st.session_state.active_mode = "Fast"


def build_config(selected_mode: str) -> Tuple[EVIRAGConfig, bool]:
    preset = MODE_PRESETS[selected_mode]
    config = EVIRAGConfig(
        mode=preset["mode"],
        backend="local",
        enabled_agents=["precision", "recall", "skeptic", "counterfactual"],
        use_visual_grounding=False,
        depth_vs_speed=preset["depth_vs_speed"],
        use_epistemic_divergence=True,
        use_causal_attribution=False,
        use_temporal_tracking=True,
        auto_fallback_to_full=preset["auto_fallback_to_full"],
    )
    return config, preset["show_reasoning"]


def system_key(config: EVIRAGConfig) -> Tuple[Any, ...]:
    return (
        config.mode,
        config.depth_vs_speed,
        config.use_epistemic_divergence,
        config.use_temporal_tracking,
        config.auto_fallback_to_full,
    )


def get_system(config: EVIRAGConfig, rebuild: bool = False) -> EVIRAGSystem:
    key = system_key(config)
    system = st.session_state.systems.get(key)
    if system is None:
        system = EVIRAGSystem(config)
        st.session_state.systems[key] = system
        system.initialize_corpus(rebuild=rebuild)
    elif rebuild:
        system.initialize_corpus(rebuild=True)
    return system


def ensure_warm_system(config: EVIRAGConfig, rebuild: bool = False) -> EVIRAGSystem:
    with st.spinner("Preparing corpus chat..."):
        return get_system(config, rebuild=rebuild)


def render_sidebar(config: EVIRAGConfig):
    st.sidebar.title("Chat Settings")
    selected_mode = st.sidebar.radio(
        "Conversation Mode",
        list(MODE_PRESETS.keys()),
        index=list(MODE_PRESETS.keys()).index(st.session_state.active_mode),
        help="Fast is the default corpus chat mode. Balanced and Deep Reasoning spend more time on the full EVIRAG pipeline.",
    )
    st.session_state.active_mode = selected_mode

    st.sidebar.markdown("**What each mode does**")
    st.sidebar.markdown("- `Fast`: offline claim graph first, with automatic full fallback when needed")
    st.sidebar.markdown("- `Balanced`: full EVIRAG pipeline")
    st.sidebar.markdown("- `Deep Reasoning`: same full pipeline, intended for slower thorough runs")
    st.sidebar.markdown("- `Vanilla RAG`: simple retrieval + synthesis")

    st.sidebar.markdown("---")
    if st.sidebar.button("Warm corpus", use_container_width=True):
        ensure_warm_system(config, rebuild=False)
        st.sidebar.success("Corpus ready")

    if st.sidebar.button("Rebuild corpus graph", use_container_width=True):
        ensure_warm_system(config, rebuild=True)
        st.sidebar.success("Rebuild complete")

    with st.sidebar.expander("Developer", expanded=False):
        if st.button("Run fast vs full comparison", use_container_width=True, key="run_eval"):
            with st.spinner("Running comparison..."):
                st.session_state.evaluation_result = compare_modes(backend="local")
        if st.session_state.evaluation_result:
            st.json(st.session_state.evaluation_result.get("aggregate", {}))


def render_answer(result: Dict[str, Any]):
    if result.get("mode") == "vanilla_rag":
        st.markdown(result.get("answer", ""))
        for source in result.get("sources", []):
            st.caption(f"{source.get('title')} · score {source.get('score', 0):.3f}")
        return

    answer = result.get("answer", {})
    dominant = answer.get("dominant_view") or {}
    st.markdown(dominant.get("summary", "_No answer generated._"))

    chips = []
    chips.append(f"Confidence {answer.get('overall_confidence', 'unknown')} ({answer.get('confidence_score', 0.0):.3f})")
    pipeline = result.get("trace", {}).get("pipeline_mode")
    if pipeline:
        chips.append(pipeline)
    if result.get("statistics", {}).get("fallback_to_full"):
        chips.append("fell back to full reasoning")
    st.markdown("".join(f"<span class='mode-chip'>{chip}</span>" for chip in chips), unsafe_allow_html=True)

    citations = dominant.get("citations", [])
    if citations:
        st.markdown("**Sources behind this answer**")
        for citation in citations:
            label = citation.get("citation_label", citation.get("source_doc_title", "Unknown source"))
            st.markdown(
                f"<div class='source-card'><strong>{label}</strong><br>{citation.get('text','')}</div>",
                unsafe_allow_html=True,
            )

    alt_views = answer.get("alternative_views", [])
    if alt_views:
        with st.expander("Other viewpoints in the corpus", expanded=False):
            for idx, view in enumerate(alt_views, start=1):
                st.markdown(f"**{idx}. {view.get('name', 'View')}**")
                st.write(view.get("summary", ""))


def render_reasoning(result: Dict[str, Any]):
    trace = result.get("trace") or {}
    if not trace:
        st.info("No reasoning trace available.")
        return

    cols = st.columns(3)
    cols[0].metric("Pipeline", trace.get("pipeline_mode", "unknown"))
    cols[1].metric("Speed setting", trace.get("requested_speed", "unknown"))
    fallback = trace.get("fallback", {}) or {}
    cols[2].metric("Fallback", "Yes" if fallback.get("triggered") or result.get("statistics", {}).get("fallback_to_full") else "No")

    if fallback.get("reason"):
        st.warning(fallback["reason"])

    with st.expander("Reasoning steps", expanded=True):
        for step in trace.get("steps", []):
            st.markdown(f"**{step.get('step', 'step')}**")
            st.json(step)

    with st.expander("Models and components", expanded=False):
        st.json(trace.get("models", {}))


def render_claims_graph_metrics(result: Dict[str, Any]):
    claims = result.get("claims", [])
    graph = result.get("graph", {})
    metrics = result.get("metrics", {})
    stats = result.get("statistics", {})

    tab_claims, tab_graph, tab_metrics = st.tabs(["Claims", "Graph", "Metrics"])

    with tab_claims:
        if claims:
            rows = [
                {
                    "claim_id": claim.get("claim_id"),
                    "text": claim.get("text"),
                    "source": claim.get("citation_label"),
                }
                for claim in claims
            ]
            st.dataframe(pd.DataFrame(rows), use_container_width=True)
        else:
            st.info("No structured claims available.")

    with tab_graph:
        st.write(f"Nodes: {len(graph.get('nodes', []))}")
        st.write(f"Edges: {len(graph.get('edges', []))}")
        if graph.get("edges"):
            st.dataframe(pd.DataFrame(graph["edges"]), use_container_width=True)
        else:
            st.info("No graph edges available.")

    with tab_metrics:
        st.json({
            "metrics": metrics,
            "statistics": stats,
            "epistemic_divergence": result.get("epistemic_divergence"),
            "temporal_drift": result.get("temporal_drift"),
        })


def render_message(message: Dict[str, Any], show_reasoning: bool):
    with st.chat_message(message["role"]):
        if message["role"] == "user":
            st.markdown(message["content"])
            return

        result = message["result"]
        render_answer(result)
        if show_reasoning:
            with st.expander("Reasoning", expanded=False):
                render_reasoning(result)
        with st.expander("Evidence and metrics", expanded=False):
            render_claims_graph_metrics(result)


def main():
    initialize_session_state()
    config, show_reasoning = build_config(st.session_state.active_mode)
    render_sidebar(config)

    st.title("EVIRAG")
    st.caption("Talk to your local paper corpus. Choose a reasoning mode in the sidebar and ask questions normally.")

    example_cols = st.columns(3)
    example_cols[0].caption("Try: `Does homework improve academic achievement?`")
    example_cols[1].caption("Try: `What disagreements exist about RAG effectiveness?`")
    example_cols[2].caption("Try: `Summarize the main viewpoints on this topic.`")

    st.markdown("---")

    for message in st.session_state.messages:
        render_message(message, show_reasoning=show_reasoning)

    prompt = st.chat_input("Ask a question about the corpus")
    if prompt:
        st.session_state.messages.append({"role": "user", "content": prompt})
        with st.chat_message("assistant"):
            system = ensure_warm_system(config, rebuild=False)
            with st.spinner("Searching the corpus..."):
                result = system.query(prompt, config)
                st.session_state.latest_result = result
            render_answer(result)
            if show_reasoning:
                with st.expander("Reasoning", expanded=False):
                    render_reasoning(result)
            with st.expander("Evidence and metrics", expanded=False):
                render_claims_graph_metrics(result)
        st.session_state.messages.append({"role": "assistant", "result": result})

    if st.session_state.latest_result:
        st.markdown("---")
        with st.expander("Latest result details", expanded=False):
            render_claims_graph_metrics(st.session_state.latest_result)


if __name__ == "__main__":
    main()
